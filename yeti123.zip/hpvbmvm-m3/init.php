<?php
session_start();

$title = 'Главная';
const HOST = "localhost";
const USER = "xtdtuuht";
const PASSWORD = "uK7SkJ";
const DATABASE = "xtdtuuht_m3";
$con = mysqli_connect(HOST, USER, PASSWORD, DATABASE);
mysqli_set_charset($con, "utf8");
