<main>
    <?= $nav ?>
    <section class="lot-item container">
        <h2>403 Недостаточно прав доступа</h2>
        <p>У вас нет прав доступа к данной странице.</p>
    </section>
</main>