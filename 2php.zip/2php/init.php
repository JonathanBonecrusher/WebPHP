<?php
$is_auth = 0;
$user_name = '';
$title = 'Главная';
const HOST = "localhost";
const USER = "root";
const PASSWORD = "";
const DATABASE = "xtdtuuht_m3";
$con = mysqli_connect(HOST, USER, PASSWORD,DATABASE);
mysqli_set_charset($con, "utf8");
