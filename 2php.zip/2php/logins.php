<?php
require_once ('helpers.php');
require_once ('function.php');
require_once ('init.php');
$category_list = category_list($con);
$nav = include_template('categoriya.php',['categories' => $category_list]);

$errors = [];
$required_fields =['email','password'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $errors[$field] = 'Поле не заполнено';
        }
    }
    if(!isset($errors['email']) && !isset($errors['password'])){
        $user_get = get_user($_POST['email'], $con);
        if($user_get){
            if(!password_verify($_POST['password'],$user_get['password'])){
                $errors['password'] = 'Пароль введен неверно';
            }else{
                session_start();
                $_SESSION['username'] = $user_get['name'];
                $detail_lot = header('Location: /');
                pr($_SESSION);
                print(include_template('layout.php', [
                    'is_auth' => $is_auth,
                    'user_name' => $user_name,
                    'title' => 'Вход',
                    'nav' => $nav,
                    'main' => $detail_lot]));
            }
        }else{
            $errors['email'] = 'Еmail введен неверно';
        }

    }
}

function getPostVal($name):string{
    return $_POST[$name] ?? "";
}
    $add_content = include_template('login.php',['nav' => $nav, 'errors' => $errors]);
$detail_lot = print(include_template('layout.php', [
    'is_auth' => $is_auth,
    'user_name' => $user_name,
    'title' => 'Вход',
    'main' => $add_content,
    'nav' => $nav
]));
?>
